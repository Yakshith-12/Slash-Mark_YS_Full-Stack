import jQuery from "jquery";


jQuery(($)=>{
    $.noConflict();

    //remove the loader on page load
   $("#spinner").css({"display":"none"});
});