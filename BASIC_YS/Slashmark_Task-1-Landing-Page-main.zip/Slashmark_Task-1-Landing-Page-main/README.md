# Responsive Halloween Website 🎃
### Responsive Halloween Website 🎃

- Responsive Halloween Website Using HTML, CSS & JavaScript.
- Contains animations when scrolling.
- It has three color designs (green, red and black)
- Smooth scrolling in each section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Join the channel to see more videos like this. [Kiran Rock](https://github.com/viswakiran16)

![halloween](/preview.png)


Deployed Link or preview - https://viswakiran16.github.io/Slashmark_Task-1-Landing-Page/
